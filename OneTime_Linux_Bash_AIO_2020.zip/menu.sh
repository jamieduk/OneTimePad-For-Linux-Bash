#!/bin/bash
# (c) J~Net 2020
# jnet.sytes.net
#
# https://jnet.forumotion.com/t1709-one-time-pads-for-linux-bash-tut#2649
#
# ./menu.sh
#
echo "Welcome To J~Net Dynamic Pad For Encrypting / Decrypting With OneTime 2020 Menu"
echo ""
#!/bin/bash
# Bash Menu Script Example
PS3='Please enter your choice: '
options=("Encrypt" "Decrypt" "Remove Files" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Encrypt")
            ./encrypt.sh
            echo ""
            echo "1) Encrypt
2) Decrypt
3) Remove Files
4) Quit"
            echo ""
            ;;
        "Decrypt")
            ./decrypt.sh
            echo ""
            echo "1) Encrypt
2) Decrypt
3) Remove Files
4) Quit"
            echo ""
            ;;
        "Remove Files")
            echo "You chose choice $REPLY which is $opt"
            sudo rm otp.txt
            sudo rm cipher.txt
            sudo rm dec.txt
            echo "Files Removed!"
            echo ""
            echo "1) Encrypt
2) Decrypt
3) Remove Files
4) Quit"
            echo ""
            ;;
        "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done
