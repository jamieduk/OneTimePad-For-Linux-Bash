#!/bin/bash
# (c) J~Net 2020
# jnet.sytes.net
#
# https://jnet.forumotion.com/t1709-one-time-pads-for-linux-bash-tut#2649
#
# ./encrypt.sh filename
#
echo "Welcome To J~Net Dynamic Pad For Encrypting / Decrypting With OneTime 2020"
echo ""
if [ -z "$1" ]
  then
    echo "Enter File To Encrypt"
    read filenameoftobedone
  else
    filenameoftobedone=$1
    echo "File To Be Encrypted $filenameoftobedone"
fi
#
echo ""
echo "Size of File $filenameoftobedone"
sizeoffile=$( ls -sh $filenameoftobedone )
echo "${sizeoffile}"
echo "Here we go, Encrypting $filenameoftobedone"
echo ""
./aio.sh -g $filenameoftobedone otp.txt > otp.txt
./aio.sh -e $filenameoftobedone otp.txt > cipher.txt
echo ""
echo "$filenameoftobedone Encrypted."
echo ""
cat cipher.txt
