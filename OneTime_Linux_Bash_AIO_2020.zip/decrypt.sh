#!/bin/bash
# (c) J~Net 2020
# jnet.sytes.net
#
# https://jnet.forumotion.com/t1709-one-time-pads-for-linux-bash-tut#2649
#
# ./decrypt.sh filename
#
echo "Welcome To J~Net Dynamic Pad For Encrypting / Decrypting With OneTime 2020"
echo ""
if [ -z "$1" ]
  then
    read -e -p "Enter File To Decrypt Or leave Blank For " -i "cipher.txt" filenameoftobedone
  else
    filenameoftobedone=$1
    echo "File To Be Decrypted $filenameoftobedone"
fi
#
echo ""
echo "Size of File $filenameoftobedone"
sizeoffile=$( ls -sh $filenameoftobedone )
echo "${sizeoffile}"
echo "Here we go, Decrypting $filenameoftobedone"
echo ""
./aio.sh -d $filenameoftobedone otp.txt > dec.txt

echo ""
echo "$filenameoftobedone Decrypted."
echo ""
cat dec.txt
